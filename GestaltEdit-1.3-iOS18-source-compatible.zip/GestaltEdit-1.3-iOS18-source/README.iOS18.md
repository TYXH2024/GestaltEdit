# GestaltEdit iOS 18 UI compatibility build

This source tree is intended to compile with the iOS 18-era Xcode toolchain and enter the SwiftUI UI on iOS 18.

Changes:
- iOS deployment target: 18.0
- Xcode project format lowered to 77 for Xcode 16-era compatibility
- Removed Xcode 27-only Swift compiler feature flags
- Added `GESTALTEDIT_UI_ONLY` compile-time mode
- UI no longer performs the iOS 27 support/version check on launch
- MobileGestalt/bad_query access is fail-closed and is not invoked by the UI-only build
- Automation command execution is disabled in UI-only mode
- Original iOS 27 backend remains in source for non-UI-only builds

This build is deliberately UI-only on iOS 18; it does not port the exploit to iOS 18.
